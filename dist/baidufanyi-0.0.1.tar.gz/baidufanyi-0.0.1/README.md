# cli_baidu_fanyi
command line tool built upon fanyi.baidu.com


# to do
- [ ] history cache